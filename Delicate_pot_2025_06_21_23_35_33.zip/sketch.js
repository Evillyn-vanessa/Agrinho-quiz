let questions = [
  
{
  
  text:' O que o campo fornece para a cidade?' ,
options:[ ' Alimentos', 'Tecnologia', 'Trabalho'] ,
  correct: 0
  },
  {
    text:' O que a cidade fornece para o campo?' ,
    options:[ ' Agricutura', 'Tecnologia', 'Pecuária'] ,
    correct: 1
    },
  {
    text:' Qual o maior alimento o campo transporta para a cidade?' ,
    options:[ ' Frutas', 'Soja', 'Cereais '] ,
    correct: 1
    },
  {
    text:' o que a cidade ajuda na agricultura familiar?' ,
    options:[ ' Estradas', 'Transporte', 'Fornecedo produtos'] ,
    correct: 2
    },
  {
    text:'Qual a maquina que ajuda a colher a plantação?' ,
    options:[ ' Colheitadeira', 'Tratores', 'Semeadoras'] ,
    correct: 0
    },
  {
    text:' o que conecta o campo e a cidae na agricultura familiar brasileira?' ,
    options: [ ' Infraestrutura', 'Armazém', 'Alimentos e Serviços '] ,
    correct: 2
},
];

let currentQuestion = 0;
let score = 0;
let showResult = false;

function setup() {
  createCanvas(600, 400);
  textAlign(CENTER, CENTER);
  textSize(30);
}

function draw() {
  background(220);
  
if (showResult) {  
  fill(0);
  textSize(20);
  text( ' Quiz finalizado!' , width / 2, 110);
  text('Você acertou' + score + ' de ' + questions.length + ' perguntas.', width / 2,150);
  return;
}

showQuestion(questions[currentQuestion]);
}

function showQuestion (q) { 
fill(0);
  textSize(26);
  text(q.text, width/ 2, 60);
  
  for (let i = 0; i < 3; i++){
  let x =width / 2 - 200;
    let y = 120 + i * 80;
        let w = 400;
          let h = 60;
     
    fill(255);
    rect(x, y, w, h, 10); 
    fill(0);
    text(q.options[i],x + w / 2, y + h / 2);
    }
  }
function mousePressed() {
  if ( showResult) return;
  
  for (let i= 0; i < 3; i++){
    let x = width / 2 - 200;
    let y = 120 + i * 80;
    let w = 400; 
    let h = 60;
    if ( mouseX > x && mouseX < x + w  &&  mouseY > y && mouseY < y + h) {
      if ( i ===  questions[currentQuestion].correct) {
        score++;
        }
      currentQuestion++;
      
      if (currentQuestion >= questions.length) {
        showResult = true;
        }
      break;
      }
    }
  }